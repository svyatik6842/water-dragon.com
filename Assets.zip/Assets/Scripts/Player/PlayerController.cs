using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [Header("Move Settings")]
    public float maxSpeed = 8f;
    public float acceleration = 15f;
    public float deceleration = 20f;
    public bool canMove;

    [Header("Slope Settings")]
    public float slopeAcceleration = 10f;  // сила прискорення вниз по схилу
    public float slopeFriction = 5f;       // тертя на схилі

    [Header("Jump Settings")]
    public float minJumpForce = 5f;
    public float maxJumpForce = 10f;
    public float jumpChargeSpeed = 20f;
    public Transform groundCheck;
    public float groundRadius = 0.2f;
    public LayerMask groundLayer;

    [HideInInspector]public  Rigidbody2D rb;
    private Animator anim;

    private bool isGrounded;
    private bool isJumping;
    private float currentJumpForce;

    public float moveInput;
    public float currentSpeed;

    private Vector2 groundNormal = Vector2.up;

    void Start()
    {
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, groundRadius, groundLayer);
        if (canMove)
        {
            moveInput = Input.GetAxis("Horizontal");
        }

        float posSpeed = Mathf.Abs(currentSpeed);
        if (posSpeed > 0.1 && posSpeed < 13f)
            anim.SetBool("Walk", true);
        else
            anim.SetBool("Walk", false);

        if (posSpeed > 13f)
            anim.SetBool("Run", true);
        else
            anim.SetBool("Run", false);

        // --- Прыжок ---
        if (Input.GetButtonDown("Jump") && isGrounded)
        {
            isJumping = true;
            currentJumpForce = minJumpForce;
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, currentJumpForce);
        }

        if (Input.GetButton("Jump") && isJumping)
        {
            if (rb.linearVelocity.y > 0 && currentJumpForce < maxJumpForce)
            {
                currentJumpForce += jumpChargeSpeed * Time.deltaTime;
                rb.linearVelocity = new Vector2(rb.linearVelocity.x, currentJumpForce);
            }
        }

        if (Input.GetButtonUp("Jump") && isJumping)
        {
            if (rb.linearVelocity.y > minJumpForce)
                rb.linearVelocity = new Vector2(rb.linearVelocity.x, minJumpForce);
            isJumping = false;
        }

        // --- Анимация прыжка ---
        if (!isGrounded)
        {
            if (rb.linearVelocity.y > 0.1f)
            {
                anim.SetBool("Jump", true);
                anim.SetBool("Fall", false);
            }
            else if (rb.linearVelocity.y < -0.1f)
            {
                anim.SetBool("Jump", false);
                anim.SetBool("Fall", true);
            }
        }
        else
        {
            anim.SetBool("Jump", false);
            anim.SetBool("Fall", false);
        }

        RotateToGround();

        float scale = 2;
        if (moveInput < 0)
            transform.localScale = new Vector3(-scale, scale, scale);
        else if (moveInput > 0)
            transform.localScale = new Vector3(scale, scale, scale);
    }


    void FixedUpdate()
    {
        HandleMovement();
        StickToGround();
    }

    private void HandleMovement()
    {
        // ---- Обчислюємо нахил землі ----
        Vector2 slopeDir = Vector2.right;
        if (isGrounded)
        {
            RaycastHit2D hit = Physics2D.Raycast(groundCheck.position, -transform.up, groundRadius * 2f, groundLayer);
            if (hit.collider != null)
            {
                groundNormal = hit.normal;
                slopeDir = new Vector2(groundNormal.y, -groundNormal.x).normalized;
            }
        }

        // ---- Прискорення / замедлення ----
        float targetSpeed = moveInput * maxSpeed;
        float speedDif = targetSpeed - currentSpeed;
        float accelRate = (Mathf.Abs(targetSpeed) > 0.01f) ? acceleration : deceleration;

        if (canMove)
        {
            currentSpeed += speedDif * accelRate * Time.fixedDeltaTime;
        }
        // ---- Авто-скатування по схилу ----
        float slopeForce = 0f;
        if (isGrounded)
        {
            slopeForce = Vector2.Dot(Vector2.down, slopeDir) * slopeAcceleration;
        }

        // ---- Підсумкова швидкість ----
        Vector2 velocity = rb.linearVelocity; // залишаємо Y від фізики
        velocity.x = slopeDir.x * currentSpeed + slopeDir.x * slopeForce * Time.fixedDeltaTime;
        velocity.y = rb.linearVelocity.y; // стрибки і падіння
        rb.linearVelocity = velocity;
    }

    private void StickToGround()
    {
        if (!isGrounded) return;

        RaycastHit2D hit = Physics2D.Raycast(groundCheck.position, -transform.up, groundRadius * 2f, groundLayer);
        if (hit.collider != null)
        {
            float speed = Mathf.Abs(currentSpeed);
            if (speed > maxSpeed * 0.3f)
            {
                Vector2 stickForce = -hit.normal * speed * 2f;
                rb.AddForce(stickForce, ForceMode2D.Force);
            }
        }
    }

    private void RotateToGround()
    {
        RaycastHit2D hitInfo = Physics2D.Raycast(groundCheck.position, -transform.up, groundRadius, groundLayer);
        Debug.DrawRay(groundCheck.position, -transform.up * groundRadius, Color.red);

        if (hitInfo.collider != null)
        {
            float targetAngle = Mathf.Atan2(hitInfo.normal.y, hitInfo.normal.x) * Mathf.Rad2Deg - 90f;
            float smoothedAngle = Mathf.LerpAngle(transform.eulerAngles.z, targetAngle, Time.deltaTime * 10f);
            transform.rotation = Quaternion.Euler(0, transform.eulerAngles.y, smoothedAngle);
        }
        else
        {
            float smoothedAngle = Mathf.LerpAngle(transform.eulerAngles.z, 0f, Time.deltaTime * 10f);
            transform.rotation = Quaternion.Euler(0, transform.eulerAngles.y, smoothedAngle);
        }
    }

    private void OnDrawGizmosSelected()
    {
        if (groundCheck != null)
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(groundCheck.position, groundRadius);
        }
    }
}
