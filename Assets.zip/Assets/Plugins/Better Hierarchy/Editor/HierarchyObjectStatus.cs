namespace Utilities.BetterHierarchy
{
    public struct HierarchyObjectStatus
    {
        public bool IsSelected;
        public bool IsHovered;
        public bool IsDropDownHovered;
    }
}