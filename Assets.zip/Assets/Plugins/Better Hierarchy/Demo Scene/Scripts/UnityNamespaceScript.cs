using UnityEngine;

namespace BetterHierarchy.UnityNamespaceExample
{
    public class UnityNamespaceScript : MonoBehaviour
    {
        
    }
}