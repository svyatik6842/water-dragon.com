using UnityEngine;

namespace BetterHierarchy.Example
{
    public class UserScriptExample : MonoBehaviour
    {

    }
}